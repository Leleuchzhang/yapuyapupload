<?php
error_reporting(0);
require_once 'user.php';
header('Content-type: text/html; charset=utf-8');
$zaixian = check_wap($_GET['url']);
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta charset="UTF-8">
<title> 千亿弹幕播放器1.6交流群：1040512177 </title>
<link rel="stylesheet" href="./qianyi/css/qianyi.css">
<style> 
.qianyi-full-icon span svg,.qianyi-fulloff-icon span svg{display: none;}
.qianyi-full-icon span,.qianyi-fulloff-icon span{background-size:contain!important;float: left;width: 22px;height: 22px;}
.qianyi-full-icon span{background: url(./qianyi/img/full.png) center no-repeat;}
.qianyi-fulloff-icon span{background: url(./qianyi/img/fulloff.webp.jpg) center no-repeat;}
#loading-box {background: #!important;}
</style>
<script src="./qianyi/js/qianyi.js"></script>
<script src="./qianyi/js/md5.min.js"></script>
<script src="./qianyi/js/jquery.min.js"></script>
<script src="./qianyi/js/hls.min.js"></script>
<script src="./qianyi/js/layer.js"></script>

<script>
var css ='<style type="text/css">';
var d, s ;
d = new Date();
s = d.getHours();
if(s<17 || s>23){ 
css+='#loading-box{background: #fff;}';//白天
}else{
css+='#loading-box{background: #000;}';//晚上
}
css+='</style>';
//$('head').append(css).addClass("");
</script>

</head>
<body>
<div id="player"></div>
<script>
    // 播放器基本设置
    var playlink ="",urlpar ='qianyi';
    var dmapi = '//www.qianyicp.com/tp/index.php',vodurl = '<?php echo $_GET['url']; ?>',vodid="",vodsid="",vodpic="",vodname="",next = "";
    var pic="https://ae01.alicdn.com/kf/H222eb1400c714319a40e62c742cc834bv.jpg";
    var playnext = "https://www.qianyicp.com/"+next ;
    var user = '',group = "",color = '#00a1d6',logo ='',autoplay = false;
    var danmuon = 1,laoding = 1,diyvodid = 0,pause_ad = 0,usernum = "<?php echo $zaixian; ?>";;
	var pbgjz = ['草','操','妈','逼','滚','网址','网站','支付宝','企','q','n','o','c','m','e','垃圾','微信','qq','卧槽','影视'];
    if(playlink!=''){ }else {var diyvodid = 1;};
    var dmrule = "https://www.qianyicp.com/liyi.html",
    diyid = md5(vodurl),diysid = 1;
    function video_end() {alert("播放结束啦=。=")};
</script>
<script src="./qianyi/js/ckey.js?v=1.6"></script>
<script type="text/javascript" src="https://js.users.51.la/20624419.js"></script>
</body>
</html>