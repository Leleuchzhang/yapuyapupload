<?php
$exclude_id = $post->ID; 
$limit = _MBT('post_related_num')?_MBT('post_related_num'):'6';
$cats = ''; foreach ( get_the_category() as $cat ) $cats .= $cat->cat_ID . ',';
$args = array(
    'category__in'        => explode(',', $cats), 
    'post__not_in'        => explode(',', $exclude_id),
    'ignore_sticky_posts' => 1,
    'posts_per_page'      => $limit
);
query_posts($args);
if(have_posts()) :
    echo '<div class="single-related"><h3 class="related-title">'.(_MBT('post_related_title')?_MBT('post_related_title'):'猜你喜欢').'</h3><div class="grids clearfix">';
    while( have_posts() ) :
        the_post();
        get_template_part( 'content', get_post_format() );
    endwhile;
    echo '</div></div>';
endif;
wp_reset_query();
