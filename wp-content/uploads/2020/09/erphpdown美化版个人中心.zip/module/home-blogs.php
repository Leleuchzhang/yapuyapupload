<div class="home-blogs">
	<div class="container">
		<h2><span><?php echo _MBT('blog_name')?_MBT('blog_name'):'博客';?></span></h2>
		<p class="desc"><?php echo _MBT('blog_desc');?></p>
		<ul class="clearfix">
			<?php 
				$args = array(
					'post_type'        => 'blog',
					'showposts'        => _MBT('home_blog_num')?_MBT('home_blog_num'):6
				);
				query_posts($args);
				while (have_posts()) : the_post(); 
			?>
			<li<?php if(!MBThemes_thumbnail_has()) echo ' class="nopic"';?>>
				<?php if(MBThemes_thumbnail_has()){?>
				<div class="img"><a href="<?php the_permalink();?>" title="<?php the_title();?>" target="_blank" rel="bookmark">
				    <img <?php echo (_MBT('lazyload') && !_MBT('waterfall'))?'data-src':'src';?>="<?php echo MBThemes_thumbnail();?>" class="thumb" alt="<?php the_title();?>">
				</a></div>
				<?php }?>
				<h3 itemprop="name headline"><a itemprop="url" rel="bookmark" href="<?php the_permalink();?>" title="<?php the_title();?>" target="_blank"><?php the_title();?></a></h3>
				<div class="excerpt-meta">
				    <?php if(_MBT('post_date')){?><span class="time"><i class="dripicons dripicons-clock"></i> <?php echo MBThemes_timeago( get_gmt_from_date(get_the_time('Y-m-d G:i:s')) ) ?></span><?php }?><?php if(_MBT('post_views')){?><span class="views"><i class="dripicons dripicons-preview"></i> <?php MBThemes_views();?></span><?php }?>
				</div>
			</li>
			<?php endwhile; wp_reset_query();?>
		</ul>
		<div class="more"><a href="<?php echo get_post_type_archive_link('blog');?>" target="_blank">查看更多</a></div>
	</div>
</div>