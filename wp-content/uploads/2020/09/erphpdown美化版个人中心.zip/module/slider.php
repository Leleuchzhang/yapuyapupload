<link rel="stylesheet" href="<?php bloginfo('template_url');?>/static/css/swiper.min.css">
<div class="swiper-container">
    <div class="swiper-wrapper">
    	<?php 
    		$sort = '1 2 3 4 5';
		    $sort = array_unique(explode(' ', trim($sort)));
		    $i = 0;
		    foreach ($sort as $key => $value) {
		        if( _MBT('slider_img'.$value) ){
    	?>
        <div class="swiper-slide" style="background-image: url(<?php echo _MBT('slider_img'.$value);?>);">
			<div class="container">
		    	<h2><?php echo _MBT('slider_title'.$value);?></h2>
		        <p><?php echo _MBT('slider_desc'.$value);?></p>
		        <?php if(_MBT('slider_btn'.$value)){?><a href="<?php echo _MBT('slider_link'.$value);?>" target="_blank"><?php echo _MBT('slider_btn'.$value);?></a><?php }?>
		    </div>
        </div>
    	<?php }}?>
    </div>
    <div class="swiper-pagination"></div>
</div>
<script src="<?php bloginfo('template_url');?>/static/js/swiper.min.js"></script>
<script>
    var swiper = new Swiper('.swiper-container', {
      slidesPerView: '1',
      autoHeight: true,
      autoplay: {
        delay: 4000,
        disableOnInteraction: false,
      },
      pagination: {
        el: '.swiper-pagination',
        dynamicBullets: true,
        clickable: true,
      },
    });
</script>