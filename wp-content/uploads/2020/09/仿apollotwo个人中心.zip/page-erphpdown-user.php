<?php 
/*
Template Name: 个人中心
Version: 9.00
*/
if(!is_user_logged_in()){
	echo "<script>window.location.href='".wp_login_url()."';</script>";
}
$current_user = wp_get_current_user();
global $wpdb;
$user_info=wp_get_current_user();

function mobantu_paging($type,$paged,$max_page) {
	if ( $max_page <= 1 ) return; 
	if ( empty( $paged ) ) $paged = 1;
	
	echo '';
	echo "";
	if($paged > 1){
		echo '';
	}
	if ( $paged > 2 ) echo "";
	for( $i = $paged - 1; $i <= $paged + 3; $i++ ) { 
		if ( $i > 0 && $i <= $max_page ) 
		{
			if($i == $paged) 
				print "";
			else
				print "";
		}
	}
	if ( $paged < $max_page - 3 ) echo "";
	if($paged < $max_page){
		echo '';
	}
	echo "";
	echo '';
}

if($_POST)
{
	if($_POST['ice_alipay']){
		$fee=get_option("ice_ali_money_site");
		$fee=isset($fee) ?$fee :100;
		$userMoney=$wpdb->get_row("select * from ".$wpdb->iceinfo." where ice_user_id=".$user_info->ID);
		/////////////////////////////////////////////////www.mobantu.com   82708210@qq.com
		if(!$userMoney)
		{
			$okMoney=0;
		}
		else 
		{
			$okMoney=$userMoney->ice_have_money - $userMoney->ice_get_money;
		
		}
		$ice_alipay = $wpdb->escape($_POST['ice_alipay']);
		$ice_name   = $wpdb->escape($_POST['ice_name']);
		$ice_money  = isset($_POST['ice_money']) && is_numeric($_POST['ice_money']) ?$_POST['ice_money'] :0;
		$ice_money = $wpdb->escape($ice_money);
		if($ice_money<get_option(ice_ali_money_limit))
		{
			echo '<div class="alert"><p>提现金额至少得满'.get_option(ice_ali_money_limit).get_option(ice_name_alipay).'</p></div>';
		}
		elseif(empty($ice_name) || empty($ice_alipay))
		{
			echo '<div class="alert"><p>请输入支付宝帐号和姓名</p></div>';
		}
		elseif($ice_money > $okMoney)
		{
			echo '<div class="alert"><p>提现金额大于可提现金额'.$okMoney.'</p></div>';
		}
		else
		{
	
			$sql="insert into ".$wpdb->iceget."(ice_money,ice_user_id,ice_time,ice_success,ice_success_time,ice_note,ice_name,ice_alipay)values
				('".$ice_money."','".$user_info->ID."','".date("Y-m-d H:i:s")."',0,'".date("Y-m-d H:i:s")."','','$ice_name','$ice_alipay')";
			if($wpdb->query($sql))
			{
				addUserMoney($user_info->ID, '-'.$ice_money);
				echo '<div class="alert"><p>申请成功，等待管理员处理！</p></div>';
			}
			else
			{
				echo '<div class="alert"><p>系统错误，请稍后重试！</p></div>';
			}
		}
	}
	if($_POST['paytype']){
		$paytype=intval($_POST['paytype']);
		$doo = 1;
		
		if(isset($_POST['paytype']) && $paytype==3)
		{
			$url=get_bloginfo('url')."/wp-content/plugins/erphpdown/payment/chinabank.php?ice_money=".$wpdb->escape($_POST['ice_money']);
		}
		elseif(isset($_POST['paytype']) && $paytype==1)
		{
			$url=get_bloginfo('url')."/wp-content/plugins/erphpdown/payment/alipay.php?ice_money=".$wpdb->escape($_POST['ice_money']);
		}
		elseif(isset($_POST['paytype']) && $paytype==5)
		{
			$url=get_bloginfo('url')."/wp-content/plugins/erphpdown/payment/f2fpay.php?ice_money=".$wpdb->escape($_POST['ice_money']);
		}
		elseif(isset($_POST['paytype']) && $paytype==7)
		{
			$url=get_bloginfo('url')."/wp-content/plugins/erphpdown/payment/tenpay.php?ice_money=".$wpdb->escape($_POST['ice_money']);
		}
		elseif(isset($_POST['paytype']) && $paytype==4)
		{
			$url=get_bloginfo('url')."/wp-content/plugins/erphpdown/payment/weixin.php?ice_money=".$wpdb->escape($_POST['ice_money']);
		}
		elseif(isset($_POST['paytype']) && $paytype==8)
		{
			$url=get_bloginfo('url')."/wp-content/plugins/erphpdown/payment/alipay_jk.php?ice_money=".$wpdb->escape($_POST['ice_money']);
		}
		elseif(isset($_POST['paytype']) && $paytype==2)
		{
			$url=get_bloginfo('url')."/wp-content/plugins/erphpdown/payment/paypal.php?ice_money=".$wpdb->escape($_POST['ice_money']);
		}
		elseif(isset($_POST['paytype']) && $paytype==9)
	    {
	        $url=constant("erphpdown")."payment/xhpay.php?ice_money=".esc_sql($_POST['ice_money'])."&type=1";
	    }
	    elseif(isset($_POST['paytype']) && $paytype==10)
	    {
	        $url=constant("erphpdown")."payment/xhpay.php?ice_money=".esc_sql($_POST['ice_money'])."&type=2";
	    }
	    elseif(isset($_POST['paytype']) && $paytype==11)
	    {
	        $url=constant("erphpdown")."payment/xhpay2.php?ice_money=".esc_sql($_POST['ice_money'])."&type=1";
	    }
	    elseif(isset($_POST['paytype']) && $paytype==12)
	    {
	        $url=constant("erphpdown")."payment/xhpay2.php?ice_money=".esc_sql($_POST['ice_money'])."&type=2";
	    }
	    elseif(isset($_POST['paytype']) && $paytype==18)
		{
			$url=constant("erphpdown")."payment/xhpay3.php?ice_money=".esc_sql($_POST['ice_money'])."&type=2";
		}
		elseif(isset($_POST['paytype']) && $paytype==17)
		{
			$url=constant("erphpdown")."payment/xhpay3.php?ice_money=".esc_sql($_POST['ice_money'])."&type=1";
		}
	    elseif(isset($_POST['paytype']) && $paytype==13)
	    {
	        $url=constant("erphpdown")."payment/codepay.php?ice_money=".esc_sql($_POST['ice_money'])."&type=1";
	    }elseif(isset($_POST['paytype']) && $paytype==14)
	    {
	        $url=constant("erphpdown")."payment/codepay.php?ice_money=".esc_sql($_POST['ice_money'])."&type=3";
	    }elseif(isset($_POST['paytype']) && $paytype==15)
	    {
	        $url=constant("erphpdown")."payment/codepay.php?ice_money=".esc_sql($_POST['ice_money'])."&type=2";
	    }elseif(isset($_POST['paytype']) && $paytype==16)
	    {
	        $url=constant("erphpdown")."payment/youzan.php?ice_money=".esc_sql($_POST['ice_money']);
	    }
		else{
			
		}
		if($doo) echo "<script>location.href='".$url."'</script>";
		exit;
	}
	if($_POST['userType']){
		$userType=isset($_POST['userType']) && is_numeric($_POST['userType']) ?intval($_POST['userType']) :0;
		if($userType >6 && $userType < 11){
			$okMoney=erphpGetUserOkMoney();
			$priceArr=array('7'=>'ciphp_month_price','8'=>'ciphp_quarter_price','9'=>'ciphp_year_price','10'=>'ciphp_life_price');
			$priceType=$priceArr[$userType];
			$price=get_option($priceType);
			if(empty($price) || $price<1){
				echo "<script>alert('此类型的会员价格错误，请稍候重试！');</script>";
			}elseif($okMoney < $price){
				echo "<script>alert('当前可用余额不足完成此次交易！');</script>";
			}
			elseif($okMoney >=$price){
				if(erphpSetUserMoneyXiaoFei($price)){
					if(userPayMemberSetData($userType)){
						addVipLog($price, $userType);
						$RefMoney=$wpdb->get_row("select * from ".$wpdb->users." where ID=".$user_info->ID);
						if($RefMoney->father_id > 0){
							addUserMoney($RefMoney->father_id,$price*get_option('ice_ali_money_ref')*0.01);
						}
					}else{
						echo "<script>alert('系统发生错误，请联系管理员！');</script>";
					}
				}else{
					echo "<script>alert('系统发生错误，请稍候重试！');</script>";
				}
			}else{
				echo "<script>alert('未定义的操作！');</script>";
			}
		}else{
			echo "<script>alert('会员类型错误！');</script>";
		}
	}
	
	if($_POST['action'] == 'card'){
		$cardnum = $wpdb->escape($_POST['epdcardnum']);
		$cardpass = $wpdb->escape($_POST['epdcardpass']);
		$result = checkDoCardResult($cardnum,$cardpass);
		if($result == '5'){
			echo "<script>alert('充值卡不存在！');</script>";
		}elseif($result == '0'){
			echo "<script>alert('充值卡已被使用！');</script>";
		}elseif($result == '2'){
			echo "<script>alert('充值卡密码错误！');</script>";
		}elseif($result == '1'){
			echo "<script>alert('充值成功！');</script>";
		}else{
			echo "<script>alert('系统错误，请稍后重试！');</script>";
		}
	}elseif($_POST['action'] == 'mycredto'){
		$epdmycrednum = $wpdb->escape($_POST['epdmycrednum']);
		if(is_numeric($epdmycrednum) && $epdmycrednum > 0 && get_option('erphp_mycred') == 'yes'){
			if(floatval(mycred_get_users_cred( $user_info->ID )) < floatval($epdmycrednum*get_option('erphp_to_mycred'))){
				$mycred_core = get_option('mycred_pref_core');
				echo "<script>alert('mycred剩余".$mycred_core['name']['plural']."不足！');</script>";
			}
			else
			{
				mycred_add( '兑换', $user_info->ID, '-'.$epdmycrednum*get_option('erphp_to_mycred'), '兑换扣除%plural%!', date("Y-m-d H:i:s") );
				$money = $epdmycrednum;
				if(addUserMoney($user_info->ID, $money))
				{
					$sql="INSERT INTO $wpdb->icemoney (ice_money,ice_num,ice_user_id,ice_time,ice_success,ice_note,ice_success_time,ice_alipay)
					VALUES ('$money','".date("y").mt_rand(10000000,99999999)."','".$user_info->ID."','".date("Y-m-d H:i:s")."',1,'4','".date("Y-m-d H:i:s")."','')";
					$wpdb->query($sql);
					echo "<script>alert('兑换成功！');</script>";
				}
				else
				{
					echo "<script>alert('兑换失败！');</script>";
				}
			}
		}
	}
	
}
?>

<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, viewport-fit=cover">
  <link rel='stylesheet' href="<?php echo ERPHPDOWN_URL.'/static/profile/erphpdown.css' ?>" type='text/css' media='all' />
<link rel="stylesheet" href="<?php echo esc_url( home_url( '/' ) ); ?>wp-content/diy/apollo.css" type="text/css">
  <link href="https://cdn.bootcss.com/simple-line-icons/2.4.1/css/simple-line-icons.css" rel="stylesheet">
	<?php wp_head(); ?>
</head>

<body <?php body_class('nice-apollo-two'); ?>>
      <header class="apollo-header bg-dark bg-img cover" style="background-image: url('https://api.dujin.org/bing/1366.php');" ><meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<nav class="navbar navbar-expand-md navbar-dark"><div class="container">
			<a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo cosy19_get_logo() ?>" alt="" class="loaded" ></a>
			
			<ul class="navbar-nav flex-row align-items-center">
<li class="nav-item">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="nav-link pr-3">
						<i class="text-md iconfont icon-homepage mr-2" data-toggle="cosytooltip" data-placement="bottom" title="" data-original-title="回到首页" style="width:auto;"></i>
					</a>
				</li>
        				
								<li class="nav-item nice-dropdown">
					<a class="nav-link dropdown-toggle pr-0" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
						<span class="flex-avatar w-32">
							
                          <?php echo get_avatar( $current_user->data->ID, 32, '', '', array('class' => '') ); ?>
                        
					</a>
										<div class="nice-dropdown-menu dropdown-menu-right text-center" aria-labelledby="UserDropdown">
						<a class="dropdown-item" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="nofollow" target="_blank">
                        <i class="text-md iconfont icon-homepage mr-2" style="width: 15.2px;"></i><?php _e('回到首页', 'cosy19') ?>
                    </a>                 
                    <a class="dropdown-item" href="<?php echo esc_url( home_url( '/' ) ); ?>/user?pd=info" rel="nofollow" target="_blank">
                        <i class="text-md iconfont icon-setting mr-2" style="width: 15.2px;"></i><?php _e('账户设置', 'cosy19') ?>
                    </a>
                    <a class="dropdown-item" href="<?php echo wp_logout_url($redirect_url) ?>" rel="nofollow" target="_blank">
                        <i class="text-md iconfont icon-close-down mr-2" style="width: 15.2px;"></i><?php _e('退出登录', 'cosy19') ?>
                    </a>
					</div>
				</li>
			</ul>
</div>
	</nav><div class="container">
		<div class="apollo-user-meta py-4 mt-4 mt-md-5">
    <div class="d-flex flex-fill flex-column flex-md-row align-items-md-center">
        <div class="mb-3 mb-md-0">
            <div class="flex-avatar w-96 rounded">
              <?php echo get_avatar( $current_user->data->ID, 96, '', '', array('class' => '') ); ?>
               
                       </div>
        </div>
        <div class="text-white mx-md-4 flex-fill">
            <div class="name text-lg"><span class=""><?php   
global $current_user, $display_name , $user_email;  
get_currentuserinfo();
  echo $display_name . "" . $user_email; ?> <i class="cut"></i>
              <span class="badge badge-rank badge-primary text-xs mx-1">
              <?php 
							$ciphp_year_price    = get_option('ciphp_year_price');
							$ciphp_quarter_price = get_option('ciphp_quarter_price');
							$ciphp_month_price  = get_option('ciphp_month_price');
							$ciphp_life_price  = get_option('ciphp_life_price');
							
                            $userTypeId=getUsreMemberType();
                            if($userTypeId==7)
                            {
                                echo '包月VIP';
                            }
                            elseif ($userTypeId==8)
                            {
                                echo '包季VIP';
                            }
                            elseif ($userTypeId==9)
                            {
                                echo '包年VIP';
                            }
							elseif ($userTypeId==10)
                            {
                                echo '终身VIP';
                            }
                            else 
                            {
                                echo '普通用户';
                            }
                            ?>
              
              </span></span></div>
            <div class="desc text-xs text-light h-1x mt-1"></div>
            
            <div class="data mt-2">
                <span class="mr-3">
                    <a href="" class="">
                        <span class="font-theme text-lg text-white"><?php echo ($userTypeId>0 && $userTypeId<10) ?''.getUsreMemberTypeEndTime() :''?></span><small class=" text-xs text-light mx-1">会员到期</small>
                    </a>
                </span>
              
            </div>
        </div>
    </div>
</div>		
		
	</div>
	</header>

  <div class="container">
	<div class="navbar-apollo mt-3 mt-md-4">
		<div class="nav">
			
<a href="?pd=info" class="nav-link <?php if($_GET["pd"]=='info' || !isset($_GET["pd"])){?>active<?php }?>">
    <span class="d-block " data-toggle="cosytooltip" data-placement="bottom" title="" data-original-title="账户设置"><i class="icon icon-user"></i></span>
</a>
<a href="?pd=money" class="nav-link <?php if($_GET["pd"]=='money'){?>active<?php }?>">
    <span class="d-block" data-toggle="cosytooltip" data-placement="bottom" title="" data-original-title="余额充值"><i class="icon icon-wallet"></i></span>
</a>
<a href="?pd=vip" class="nav-link <?php if($_GET["pd"]=='vip'){?>active<?php }?>">
    <span class="d-block" data-toggle="cosytooltip" data-placement="bottom" title="" data-original-title="开通会员"><i class="icon icon-badge"></i></span>
</a>
<a href="?pd=ref" class="nav-link <?php if($_GET["pd"]=='ref'){?>active<?php }?>">
    <span class="d-block" data-toggle="cosytooltip" data-placement="bottom" title="" data-original-title="推广返现"><i class="icon icon-share-alt"></i></span>
</a>
<a href="?pd=cart" class="nav-link <?php if($_GET["pd"]=='cart'){?>active<?php }?>">
    <span class="d-block" data-toggle="cosytooltip" data-placement="bottom" title="" data-original-title="我的下载"><i class="icon icon-cloud-download"></i></span>
</a>
          
          
	</div>
	</div>
</div>

<main class="py-4">	
<div class="container" id="profile" >
          <div class="input-inner mb-3 mb-md-4">
			<?php if($_GET["pd"]=='info' || !isset($_GET["pd"])){////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////个人信息?>
			<div id="infocenter" class="apollo-card">
				<?php 
					global $current_user;
				?>
			   <div class="p-4">
					<form action="" method="post">
					<dl class="form-group">
						<label for="display_name" class="text-muted text-sm">用户名</label>
                      <input type="text" class="form-control form-control-lg" id="mm_name" name="mm_name" value="<?php echo esc_attr( $current_user->user_login ); ?>" disabled="disabled">
					</dl>
					<dl class="form-group">
						<label for="display_name" class="text-muted text-sm">昵称</label>
							<input type="text" class="profile-input form-control form-control-lg" id="mm_name" name="mm_name" value="<?php echo esc_attr( $current_user->nickname ) ?>">
					</dl>
					<dl class="form-group">
						<label for="display_name" class="text-muted text-sm">邮箱</label>
							<input type="text" class="profile-input form-control form-control-lg" id="mm_mail" name="mm_mail" value="<?php echo esc_attr( $current_user->user_email ) ?>">
					</dl>
					<dl class="form-group">
						<label for="display_name" class="text-muted text-sm">个人介绍</label>
							<textarea rows="4" class="profile-input form-control form-control-lg" id="mm_desc" name="mm_desc"><?php echo esc_html( $current_user->description ); ?></textarea>
					</dl>
					<dl class="form-group">
							<input type="button" id="doprofile" value="保存" class="btn btn-primary btn-primary-1 mt-2"/>  
					</dl>
					</form>
			</div>
		</div>
            </div>
           
          <div id="changepass" class="apollo-card">
              <div class="p-4">
                  <label for="display_name" class="text-muted text-sm">修改密码</label>
				<div class="profile-form">
					<form action="" method="post" class="row">
					<dl class="col-xs-12 col-sm-6 col-md-6 dl-horizontal">
							<input type="password" id="mm_pass_new" name="mm_pass_new" value="" class="form-control form-control-lg" placeholder="新密码">
					</dl>
					<dl class="col-xs-12 col-sm-6 col-md-6 dl-horizontal">
							<input type="password" id="mm_pass_new2" name="mm_pass_new2" value="" class="form-control form-control-lg" placeholder="确认密码">
					</dl>
					<dl class="col-xs-12 col-sm-6 col-md-6 dl-horizontal">
							<input type="button" id="dopassword" value="保存" class="btn btn-primary btn-primary-1 mt-2"/>
					</dl>
					</form>
				</div>
              </div>
            </div>
            
          
			<script type="text/javascript">
				jQuery(document).ready(function($){
				
					$("#doprofile").click(function(){ 
						var reg = /^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/ ;
						if($("#mm_name").val().trim().length==0)
						{
							alert("请输入昵称");
						}
						else if(strlen($("#mm_name").val().trim())<4)
						{
							alert("昵称长度至少为4位");
						}
						else if(!reg.test($("#mm_mail").val().trim()))
						{
							alert("请输入正确邮箱，以免忘记密码时无法找回");
						}
						else
						{
							$("#doprofile").val("保存中...");
							$("#doprofile").css("width","80px");
							$.ajax({
								type: "post",
								url: "<?php echo ERPHPDOWN_URL; ?>/admin/action/ajax-profile.php",
								data: "do=profile&mm_name=" + $("#mm_name").val() + "&mm_mail=" + $("#mm_mail").val() + "&mm_url=" + $("#mm_url").val() + "&mm_desc=" + $("#mm_desc").val(),
								dataType: "text",
								success: function (data) {
									$("#doprofile").val("保存");
									$("#doprofile").css("width","60px");
									alert("修改成功");
								},
								error: function () {
								   $("#doprofile").val("保存");
									$("#doprofile").css("width","60px");
									alert("error");
								}
							});
						}
					});
				
				});
			</script>
         
			
			<script type="text/javascript">
				jQuery(document).ready(function($){
				
					$("#dopassword").click(function(){ 
						if($("#mm_pass_new").val().trim().length==0)
						{
							alert("请输入密码");
						}
						else if(strlen($("#mm_pass_new").val().trim())<6)
						{
							alert("密码长度至少为6位");
						}
						else if($("#mm_pass_new2").val().trim() != $("#mm_pass_new").val().trim())
						{
							alert("两次密码不一致");
						}
						else
						{
							$("#dopassword").val("保存中...");
							$("#dopassword").css("width","80px");
							$.ajax({
								type: "post",
								//async: false,
								url: "<?php echo ERPHPDOWN_URL; ?>/admin/action/ajax-profile.php",
								data: "do=password&mm_usrname="+$("#mm_usrname").val()+"&mm_pass_old=" + $("#mm_pass_old").val() + "&mm_pass_new=" + $("#mm_pass_new").val() + "&mm_pass_new2=" + $("#mm_pass_new2").val(),
								//contentType: "application/json; charset=utf-8",
								dataType: "text",
								success: function (data) {
									$("#dopassword").val("保存");
									$("#dopassword").css("width","60px");
									alert("修改成功");
									//alert(data);
								},
								error: function () {
									$("#dopassword").val("保存");
									$("#dopassword").css("width","60px");
									alert("修改失败");
								}
							});
						}
					});
				
				
				});
			</script>
		</div>
          
          
			<?php }elseif($_GET["pd"]=='recharge'){////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////充值记录
				$totallists = $wpdb->get_var("SELECT count(*) FROM $wpdb->icemoney WHERE ice_success=1 and ice_user_id=".$user_info->ID);
				$ice_perpage = 10;
				$pages = ceil($totallists / $ice_perpage);
				$page=isset($_GET['pp']) ?intval($_GET['pp']) :1;
				$offset = $ice_perpage*($page-1);
				$lists = $wpdb->get_results("SELECT * FROM $wpdb->icemoney where ice_success=1 and ice_user_id=".$user_info->ID." order by ice_time DESC limit $offset,$ice_perpage");
				
				?>
				
            	<table class="table table-hover table-striped">
					<thead>
						<tr>
							<th>金额</th>
							<th>方式</th>
							<th>时间</th>
						</tr>
					</thead>
					<tbody>
						<?php
							if($lists) {
								foreach($lists as $value)
								{
									echo "<tr>\n";
									echo "<td>$value->ice_money</td>\n";
									if(intval($value->ice_note)==0)
									{
										echo "<td>在线充值</td>\n";
									}elseif(intval($value->ice_note)==1)
									{
										echo "<td>后台充值</td>\n";
									}
									elseif(intval($value->ice_note)==2)
									{
										echo "<td>转账收</td>\n";
									}
									elseif(intval($value->ice_note)==3)
									{
										echo "<td>转账付</td>\n";
									}elseif(intval($value->ice_note)==4)
									{
										echo "<td>积分兑换</td>\n";
									}elseif(intval($value->ice_note)==6)
									{
										echo "<td>充值卡</td>\n";
									}else{
										echo "<td>未知</td>\n";
									}
									
									echo "<td>$value->ice_time</td>";
									echo "</tr>";
								}
							}
							else
							{
								echo '<tr width=100%><td colspan="3" align="center"><center><strong>没有记录！</strong></center></td></tr>';
							}
						?>
					</tbody>
				</table>
				<?php mobantu_paging('recharge',$page,$pages);?>  
		
  
  <?php }elseif($_GET["pd"]=='vip'){////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////VIP记录
				$totallists = $wpdb->get_var("SELECT COUNT(ice_id) FROM $wpdb->vip where ice_user_id=".$user_info->ID);
				$ice_perpage = 10;
				$pages = ceil($totallists / $ice_perpage);
				$page=isset($_GET['pp']) ?intval($_GET['pp']) :1;
				$offset = $ice_perpage*($page-1);
				$lists = $wpdb->get_results("SELECT * FROM $wpdb->vip where ice_user_id=".$user_info->ID." order by ice_time DESC limit $offset,$ice_perpage");
				
				?>
  

			<div id="infocenter" class="apollo-card" style="background-color:rgba(255,255,255,0.0);">
               <form action="" method="post">
                 <table class="form-table" style="">       
                   <div class="row">
                       

                     
                     <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                       <label class="card card-pricing cart-box radio-box-1">  
                        <div class="card-body">
                          <?php if($ciphp_life_price){?>
                          <div class="icon-box">
                                    <div class="icon-box-inner small text-primary">
                                        <img src="https://s2.ax1x.com/2019/10/16/KiynM9.png">
                                    </div>
                                </div>
                          <h3 class="card-title text-primary pt-4"><?php echo $ciphp_month_price?></h3>
                          
                          <ul class="list-unstyled pricing-list">
                            <li>尊享30天特权</li>
                                    <li>极速会员线路</li>
                                    <li>海量资源下载</li>
                                    <li>专属会员福利</li>
                                </ul>
                               <input type="radio" id="userType1" name="userType" value="7" onclick="checkCard()" class="vip-info-input"/>
                                
                          <?php }?>
                            </div> 
                         </label>
                     </div>

                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                       <label class="card card-pricing cart-box radio-box-2">  
                        <div class="card-body">
                          <?php if($ciphp_life_price){?>
                          <div class="icon-box">
                                    <div class="icon-box-inner small text-primary">
                                       <img src="https://s2.ax1x.com/2019/10/16/KiyJRe.png"> 
                            </div>
                                </div>
                         <h3 class="card-title text-primary pt-4"><?php echo $ciphp_quarter_price?></h3>
                          
                          <ul class="list-unstyled pricing-list">
                            <li>尊享90天特权</li>
                                    <li>极速会员线路</li>
                                    <li>海量资源下载</li>
                                    <li>专属会员福利</li>
                                </ul>
                               <input type="radio" id="userType2" name="userType" value="8" onclick="checkCard()" class="vip-info-input"/>
                                
                          <?php }?>
                            </div> 
                         </label>
                     </div>
                
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                       <label class="card card-pricing cart-box radio-box-3">  
                        <div class="card-body">
                          <?php if($ciphp_life_price){?>
                          <div class="icon-box">
                                    <div class="icon-box-inner small text-primary">
                                         <img src="https://s2.ax1x.com/2019/10/16/KiywZt.png"> 
                            </div>
                                </div>
                        <h3 class="card-title text-primary pt-4"><?php echo $ciphp_year_price?></h3>
                          
                          <ul class="list-unstyled pricing-list">
                            <li>尊享365天特权</li>
                                    <li>极速会员线路</li>
                                    <li>海量资源下载</li>
                                    <li>专属会员福利</li>
                                </ul>
                               <input type="radio" id="userType3" name="userType" value="9" onclick="checkCard()" class="vip-info-input"/>
                                  
                          <?php }?>
                            </div> 
                         </label>
                     </div>
                
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                       <label class="card card-pricing cart-box radio-box-4">  
                        <div class="card-body">
                          <?php if($ciphp_life_price){?>
                          <div class="icon-box">
                                    <div class="icon-box-inner small text-primary">
                                         <img src="https://s2.ax1x.com/2019/10/16/KiysJS.png"> 
                            </div>
                                </div>
                         <h3 class="card-title text-primary pt-4"><?php echo $ciphp_life_price?></h3>
                          
                          <ul class="list-unstyled pricing-list">
                            <li>尊享永久特权</li>
                                    <li>极速会员线路</li>
                                    <li>海量资源下载</li>
                                    <li>专属会员福利</li>
                                </ul>
                          <label>
                               <input type="radio" id="userType4" name="userType" value="10" onclick="checkCard()" class="vip-info-input"/>
                                </label>  
                          <?php }?>
                            </div> 
                         </label>
                     </div>
         </div>
  </table>
            <div style="text-align:center;">
                           <input type="submit" name="Submit" value="开通" class="btn btn-primary btn-primary-1" onClick="return confirm('确认开通VIP?');"/>
                       </div>
     </form>  
		</div>

				<?php mobantu_paging('vip',$page,$pages);?>
  <?php }elseif($_GET["pd"]=='ref'){////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////推广
				$totallists = $wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->users WHERE father_id=".$user_info->ID);
				$ice_perpage = 10;
				$pages = ceil($totallists / $ice_perpage);
				$page=isset($_GET['pp']) ?intval($_GET['pp']) :1;
				$offset = $ice_perpage*($page-1);
				$lists = $wpdb->get_results("SELECT ID,user_login,user_registered FROM $wpdb->users where father_id=".$user_info->ID." limit $offset,$ice_perpage");
                $fee=get_option("ice_ali_money_site");
				$fee=isset($fee) ?$fee :100;
				$userMoney=$wpdb->get_row("select * from ".$wpdb->iceinfo." where ice_user_id=".$user_info->ID);
				if(!$userMoney)
				{
					$okMoney=0;
				}
				else 
				{
					$okMoney=$userMoney->ice_have_money - $userMoney->ice_get_money;
				}
				$userAli=$wpdb->get_row("select * from ".$wpdb->iceget." where ice_user_id=".$user_info->ID);
				?>
          <div class="profile-form apollo-card">
            <div class="p-4">
              <label class="text-muted text-sm">推广链接</label>
              <script src="https://cdn.bootcss.com/clipboard.js/1.7.1/clipboard.min.js"></script>
              <script src="https://cdn.bootcss.com/jquery/3.4.1/jquery.min.js"></script>
              <div style="margin-top:10px"><span id="btn" data-clipboard-text="<?php echo esc_url( home_url( '/?aff=' ) ).$user_info->ID; ?>" class="ref-span">点击复制：<?php echo esc_url( home_url( '/?aff=' ) ).$user_info->ID; ?></span></div>
<div id="show" style="margin-top:15px"><span class="ref-span" style="background-color:#009933;">已复制</span></div>
<script>
	var btn=document.getElementById('btn');
	var clipboard=new Clipboard(btn);
	clipboard.on('success', function(e){
		$('#show').slideDown().delay(1500).slideUp(300);
		console.log(e);
	});
	clipboard.on('error', function(e){
		$('#show').slideDown().delay(1500).slideUp(300);
		console.log(e);
	});
</script>
              </div>
          
            <div class="p-4">
             <label class="text-muted text-sm">申请提现</label>
					<form action="" method="post" class="row">
					<dl class="dl-horizontal col-xs-12 col-sm-12 col-md-6 tixian">
						<input type="text" class="form-control" placeholder="支付宝账号" id="ice_alipay" name="ice_alipay" value="<?php if($userAli) echo $userAli->ice_alipay;?>"/>
					</dl>
					<dl class="dl-horizontal col-xs-12 col-sm-12 col-md-6 tixian">
						<input type="text" class="form-control" placeholder="支付宝姓名" id="ice_name" name="ice_name"  value="<?php if($userAli) echo $userAli->ice_name;?>"/>
					</dl>
					<dl class="dl-horizontal col-xs-12 col-sm-12 col-md-6 tixian">
                     <input type="text" class="form-control" placeholder="手续费：<?php echo get_option("ice_ali_money_site")?>%" disabled="disabled"/>
					</dl>
					<dl class="dl-horizontal col-xs-12 col-sm-12 col-md-6 tixian">
							<input type="text" class="form-control" placeholder="金额：（剩余：<?php echo sprintf("%.2f",$okMoney)?><?php echo get_option('ice_name_alipay')?>）" id="ice_money" name="ice_money"  />
					</dl>
					<dl class="dl-horizontal col-xs-12 col-sm-12 col-md-6 tixian">
							<input type="submit" value="提交" class="btn btn-primary btn-primary-1"/>
					</dl>
					</form>
              </div>
			</div>
				<?php mobantu_paging('ref',$page,$pages);?>
			<?php }elseif($_GET["pd"]=='ref2'){////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////推广2
				$totallists = $wpdb->get_var("SELECT COUNT(ice_id) FROM $wpdb->vip where ice_user_id in (select ID from $wpdb->users where father_id=".$user_info->ID.")");
				$ice_perpage = 10;
				$pages = ceil($totallists / $ice_perpage);
				$page=isset($_GET['pp']) ?intval($_GET['pp']) :1;
				$offset = $ice_perpage*($page-1);
				$lists = $wpdb->get_results("SELECT * FROM $wpdb->vip where ice_user_id in (select ID from $wpdb->users where father_id=".$user_info->ID.") order by ice_time DESC limit $offset,$ice_perpage");
				?>
				<div class="alert"><p>推广链接&nbsp;&nbsp;&nbsp;&nbsp;<?php echo esc_url( home_url( '/?aff=' ) ).$user_info->ID; ?></p></div>
            	<table class="table table-hover table-striped">
					<thead>
						<tr>
							<th>用户ID</th>
							<th>VIP类型</th>
							<th>价格</th>
							<th>交易时间</th>
						</tr>
					</thead>
					<tbody>
						<?php
							if($lists) {
								foreach($lists as $value)
								{
									$typeName=$value->ice_user_type==7 ?'包月' :($value->ice_user_type==8 ?'包季' : ($value->ice_user_type==10 ?'终身' : '包年'));
									echo "<tr>\n";
									echo "<td>".get_the_author_meta( 'user_login', $value->ice_user_id )."</td>\n";
									echo "<td>$typeName</td>\n";
									echo "<td>$value->ice_price</td>\n";
									echo "<td>$value->ice_time</td>\n";
									echo "</tr>";
								}
							}
							else
							{
								echo '<tr width=100%><td colspan="4" align="center"><center><strong>没有记录！</strong></center></td></tr>';
							}
						?>
					</tbody>
				</table>
				<?php mobantu_paging('ref2',$page,$pages);?>
            
			<?php }elseif($_GET["pd"]=='outmo'){////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////站内提现
				$totallists = $wpdb->get_var("SELECT count(*) FROM $wpdb->iceget WHERE ice_user_id=".$user_info->ID);
				$ice_perpage = 10;
				$pages = ceil($totallists / $ice_perpage);
				$page=isset($_GET['pp']) ?intval($_GET['pp']) :1;
				$offset = $ice_perpage*($page-1);
				$lists = $wpdb->get_results("SELECT * FROM $wpdb->iceget where ice_user_id=".$user_info->ID." order by ice_time DESC limit $offset,$ice_perpage");
				?>
				<div class="alert"><p><a href="?pd=tixian">有收入了？去申请提现>></a></p></div>
            	<table class="table table-hover table-striped">
					<thead>
						<tr>
							<th>申请金额</th>
							<th>申请时间</th>
							<th>到账金额</th>
							<th>状态</th>
						</tr>
					</thead>
					<tbody>
						<?php
							if($lists) {
								foreach($lists as $value)
								{
									$result=$value->ice_success==1?'已支付':'--';
									echo "<tr>\n";
									echo "<td>$value->ice_money</td>\n";
									echo "<td>$value->ice_time</td>\n";
									echo "<td>".sprintf("%.2f",(((100-get_option("ice_ali_money_site"))*$value->ice_money)/100))."</td>\n";
									echo "<td>$result</td>\n";
									echo "</tr>";
								}
							}
							else
							{
								echo '<tr><td colspan="4" align="center"><center><strong>没有记录！</strong></center></td></tr>';
							}
						?>
					</tbody>
				</table>
				<?php mobantu_paging('outmo',$page,$pages);?>
			<?php }elseif($_GET["pd"]=='tixian'){////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////站内提现
				$fee=get_option("ice_ali_money_site");
				$fee=isset($fee) ?$fee :100;
				$userMoney=$wpdb->get_row("select * from ".$wpdb->iceinfo." where ice_user_id=".$user_info->ID);
				if(!$userMoney)
				{
					$okMoney=0;
				}
				else 
				{
					$okMoney=$userMoney->ice_have_money - $userMoney->ice_get_money;
				}
				$userAli=$wpdb->get_row("select * from ".$wpdb->iceget." where ice_user_id=".$user_info->ID);
			?>
				<div class="profile-form box-card" style="height:100%">
              
					<form action="" method="post" style="padding-top:30px;">
					<dl class="dl-horizontal col-xs-12 col-sm-12 col-md-6 tixian">
						<dd><input type="text" class="form-control" placeholder="支付宝账号" id="ice_alipay" name="ice_alipay" value="<?php if($userAli) echo $userAli->ice_alipay;?>"/></dd>
					</dl>
					<dl class="dl-horizontal col-xs-12 col-sm-12 col-md-6 tixian">
						<dd><input type="text" class="form-control" placeholder="支付宝姓名" id="ice_name" name="ice_name"  value="<?php if($userAli) echo $userAli->ice_name;?>"/></dd>
					</dl>
					<dl class="dl-horizontal col-xs-12 col-sm-12 col-md-6 tixian">
						<dd>
                     <input type="text" class="form-control" placeholder="手续费：<?php echo get_option("ice_ali_money_site")?>%" disabled="disabled"/>
						</dd>
					</dl>
					<dl class="dl-horizontal col-xs-12 col-sm-12 col-md-6 tixian">
						<dd>
							<input type="text" class="form-control" placeholder="金额：（剩余：<?php echo sprintf("%.2f",$okMoney)?><?php echo get_option('ice_name_alipay')?>）" id="ice_money" name="ice_money"  />
						</dd>
					</dl>
					<dl class="dl-horizontal col-xs-12 col-sm-12 col-md-6 tixian">
						<dt></dt>
						<dd>
							<input type="submit" value="提交申请" class="btn btn-primary btn-primary-1"/>
						</dd>
					</dl>
					</form>
               
				</div>
  
			<?php }elseif($_GET["pd"]=='pass'){////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////修改密码?>
			
			<div id="changepass" class="box-card">
				<div class="alert" style="margin-top:30px;">为了确保安全，密码最好是由“字母+字符+数字”组成！</div>
				<div class="profile-form" style="text-align:center">
					<form action="" method="post">
					<dl class="dl-horizontal col-xs-12 col-sm-12 col-md-12">
						<dd>
							<input type="password" id="mm_pass_new" name="mm_pass_new" value="" class="form-control" placeholder="新密码">
						</dd>
					</dl>
					<dl class="dl-horizontal col-xs-12 col-sm-12 col-md-12">
						<dd>
							<input type="password" id="mm_pass_new2" name="mm_pass_new2" value="" class="form-control" placeholder="确认密码">
						</dd>
					</dl>
					<dl class="dl-horizontal col-xs-12 col-sm-12 col-md-12">
						<p></p>
						<dd>
							<input type="button" id="dopassword" value="保存" class="btn btn-primary btn-primary-1"/>
						</dd>
					</dl>
					</form>
				</div>
			</div>
			
			<script type="text/javascript">
				jQuery(document).ready(function($){
				
					$("#dopassword").click(function(){ 
						if($("#mm_pass_new").val().trim().length==0)
						{
							alert("请输入密码");
						}
						else if(strlen($("#mm_pass_new").val().trim())<6)
						{
							alert("密码长度至少为6位");
						}
						else if($("#mm_pass_new2").val().trim() != $("#mm_pass_new").val().trim())
						{
							alert("两次密码不一致");
						}
						else
						{
							$("#dopassword").val("保存中...");
							$("#dopassword").css("width","80px");
							$.ajax({
								type: "post",
								//async: false,
								url: "<?php echo ERPHPDOWN_URL; ?>/admin/action/ajax-profile.php",
								data: "do=password&mm_usrname="+$("#mm_usrname").val()+"&mm_pass_old=" + $("#mm_pass_old").val() + "&mm_pass_new=" + $("#mm_pass_new").val() + "&mm_pass_new2=" + $("#mm_pass_new2").val(),
								//contentType: "application/json; charset=utf-8",
								dataType: "text",
								success: function (data) {
									$("#dopassword").val("保存");
									$("#dopassword").css("width","60px");
									alert("修改成功");
									//alert(data);
								},
								error: function () {
									$("#dopassword").val("保存");
									$("#dopassword").css("width","60px");
									alert("修改失败");
								}
							});
						}
					});
				
				
				});
			</script>
		
			<?php }elseif($_GET["pd"]=='cart'){////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////购物车 
			$total_trade   = $wpdb->get_var("SELECT COUNT(ice_id) FROM $wpdb->icealipay WHERE ice_success>0 and ice_user_id=".$user_info->ID);
			$ice_perpage = 10;
			$pages = ceil($total_trade / $ice_perpage);
			$page=isset($_GET['pp']) ?intval($_GET['pp']) :1;
			$offset = $ice_perpage*($page-1);
			$list = $wpdb->get_results("SELECT * FROM $wpdb->icealipay where ice_success=1 and ice_user_id=$user_info->ID order by ice_time DESC limit $offset,$ice_perpage");
			?>
			
  
  <div class="list-apollo-postlist ajax-load-box row my-n2 my-md-n3">
                       <?php
                         
							if($list) {
								foreach($list as $value)
								{
                                  $Num1 = mt_rand(100,700);
									echo "<div class='col-12 col-md-4 col-xl-3 d-flex py-2 py-md-3'>
             <div class='apollo-card post-5112 cart-box'>
        <div class='apollo-card-body'>
            <div class='media media-3x2 mb-3'>
                                    <div class='media-content' style='background-image: url(https://picsum.photos/id/";
                                  echo $Num1;
                                  echo "/600/400);'>
                        <span class='overlay'></span>
                    </div>
                                
                <div class='media-overlay overlay-top'>
                    <div><span class='badge badge-danger'>";
                                      echo "$value->ice_price</span></div>                </div>
                            </div>
            <div class='apollo-card-content px-3'><div class='text-md h-2x' style='cursor: no-drop;'>";
									echo "<a target=_blank href=".get_permalink($value->ice_post).">$value->ice_title</a>";
									echo "</div></div>
        </div>
        <div class='apollo-card-footer'>
	<div class='font-theme text-muted text-xs p-3'>";
                                      
									echo "<a href='".get_bloginfo('wpurl').'/wp-content/plugins/erphpdown/download.php?url='.$value->ice_url."' target='_blank'><span><i class='icon icon-cloud-download'></i>  
		</span>
	</div>
</div>    </div>
</div>";
									echo $post_date;
								}
							}
							else
							{
								echo "<div class='content-error h-v-50'>
			<div class='text-center m-auto'>
				<div class='w-96 mx-auto'><svg t='1569653187001' class='icon' viewBox='0 0 1024 1024' version='1.1' xmlns='http://www.w3.org/2000/svg' p-id='843' data-spm-anchor-id='a313x.7781069.0.i1'>
                <path d='M600.5 367.1c0-12.6-10.2-22.8-22.8-22.8h-207c-12.6 0-22.8 10.2-22.8 22.8s10.2 22.8 22.8 22.8h207c12.6 0 22.8-10.2 22.8-22.8zM370.6 518.6c-12.6 0-22.8 10.2-22.8 22.8 0 12.6 10.2 22.8 22.8 22.8h109c12.6 0 22.8-10.2 22.8-22.8 0-12.6-10.2-22.8-22.8-22.8h-109z' fill='#8a92a9' p-id='844' data-spm-anchor-id='a313x.7781069.0.i4' class='selected'></path>
                <path d='M809.9 806.7L763 759.8c20.8-23.3 33.6-54 33.6-87.7 0-72.7-59.1-131.8-131.8-131.8S533 599.5 533 672.2 592.1 804 664.8 804c22.4 0 43.6-5.7 62.1-15.6l50.6 50.6c4.5 4.5 10.3 6.7 16.2 6.7 5.8 0 11.7-2.2 16.2-6.7 8.9-8.9 8.9-23.4 0-32.3zM578.7 672.2c0-47.5 38.6-86.1 86.1-86.1s86.1 38.6 86.1 86.1c0 47.5-38.6 86.1-86.1 86.1s-86.1-38.6-86.1-86.1z' fill='#e23e57' p-id='845' data-spm-anchor-id='a313x.7781069.0.i0' class=''></path>
                <path d='M501.4 780.1h-207c-23.5 0-42.5-19.1-42.5-42.5V269c0-23.5 19.1-42.5 42.5-42.5h425c23.5 0 42.5 19.1 42.5 42.5v234.3c0 12.6 10.2 22.8 22.8 22.8s22.8-10.2 22.8-22.8V269c0-48.6-39.6-88.2-88.2-88.2h-425c-48.7 0-88.2 39.6-88.2 88.2v468.6c0 48.7 39.6 88.2 88.2 88.2h207c12.6 0 22.8-10.2 22.8-22.8 0.1-12.7-10.1-22.9-22.7-22.9z' fill='#8a92a9' p-id='846' data-spm-anchor-id='a313x.7781069.0.i2' class='selected'></path></svg></div>
				<div class='text-sm text-muted mt-4'>看起来这里没有任何东西…</div>
			</div>
		</div>";
							}
						?>
</div>
  

  
			<?php }elseif($_GET["pd"]=='money'){ ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////个人资产
					$user_Info   = wp_get_current_user();
					$userMoney=$wpdb->get_row("select * from ".$wpdb->iceinfo." where ice_user_id=".$user_Info->ID);
					if(!$userMoney)
					{
						$okMoney=0;
					}
					else 
					{
						$okMoney=$userMoney->ice_have_money - $userMoney->ice_get_money;
					}
				?>
				
				<div class="apollo-card" style="background-color:rgba(255,255,255,0.0);">
                  <form class="row" id="modify-profile">
                    <div class="col-md-4 col-sm-4">
                      <div class="author-info">
                      <small><?php echo get_option('ice_name_alipay');?></small>
                      <i class="fas fa-wallet"></i><br><br>
                      <h3><?php echo sprintf("%.2f",$okMoney)?></h3><br>
                      <p>余额</p>
                   </div>
               </div>
                  <div class="col-md-4 col-sm-4">
            <div class="author-info">
                <small><?php echo get_option('ice_name_alipay');?></small>
                <i class="fa fa-shopping-cart yue"></i><br><br>
                <h3><?php echo intval($userMoney->ice_get_money)?></h3><br>
               <p>消费</p>
            </div>
        </div>
                     
               <div class="col-md-4 col-sm-4">
            <div class="author-info">
                <small>积分</small>
                 <i class="fas fa-yen-sign"></i><br><br>
                <h3><?php echo do_shortcode("[mycred_my_balance]"); ?></h3><br>
              <p>剩余</p>
            </div>
        </div>   
                  </form>
                  </div>
  
  

  
  
  
  
  <div class="apollo-card">
                  <div class="p-4">
                	<script type="text/javascript">
					function checkFm(){
						if(document.getElementById("ice_money").value=="")
						{
							alert('请输入金额');
							return false;
						}
					}
					function checkFm2(){
						if(document.getElementById("epdcardnum").value=="")
						{
							alert('请输入金额');
							return false;
						}
					}
					function checkFm3(){
						if(document.getElementById("epdmycrednum").value=="")
						{
							alert('请输入兑换的金额');
							return false;
						}
					}
					</script>
                    <?php if(function_exists("checkDoCardResult")){?>
                     <label class="text-muted text-sm">卡密充值</label>
                	<form action="" method="post" onSubmit="return checkFm2();" class="form-table form-group row">
                				<dl class="col-xs-12 col-sm-6 col-md-6">
                				<input type="text" id="epdcardnum" name="epdcardnum"  required="required" class="form-control form-control-lg" placeholder="卡号："/>
                				</dl>
                              	<dl class="col-xs-12 col-sm-6 col-md-6">
                				<input type="text" id="epdcardpass" name="epdcardpass"  required="required" class="form-control form-control-lg"  placeholder="卡密："/>
                				</dl>
                              	<dl class="col-xs-12 col-sm-6 col-md-6 submit" style="margin-top:10px;">
                            <input type="hidden" name="action" value="card">
                            <input type="submit" value="充值" class="btn btn-primary btn-primary-1"/>
                        </dl>
                	</form>
                </div>
                <?php }?>
                <?php if(plugin_check_cred() && get_option('erphp_mycred') == 'yes'){
                	$mycred_core = get_option('mycred_pref_core');
                	?>
    
           <div class="p-4">
             <label class="text-muted text-sm"><?php echo $mycred_core['name']['plural'];?>兑换</label>
                <form action="" method="post" onSubmit="return checkFm3();" class="form-table form-group row">
                	<dl class="col-xs-12 col-sm-6 col-md-6" style="margin-bottom:10px;">
                     <input type="text" id="epdmycrednum" name="epdmycrednum"  required="required" placeholder="需要兑换的<?php echo get_option('ice_name_alipay')?>数" class="form-control form-control-lg"/>
                			</dl>
                   <dl class="col-xs-12 col-sm-6 col-md-6 submit">
                            <input type="submit" name="Submit" value="兑换" class="btn btn-primary btn-primary-1" onClick="return confirm('确认兑换?');"/>
                            <input type="hidden" name="action" value="mycredto">
                       </dl> 
                  <dl class="col-xs-12 col-sm-6 col-md-6">
                          <p style="margin-top: 10px;margin-bottom: 10px;color: #8a92a9;font-size: 0.8rem;">注：请输入一个整数，<?php echo get_option('erphp_to_mycred').$mycred_core['name']['plural'];?> = 1<?php echo get_option('ice_name_alipay')?></p>
                       </dl> 
                </form>
             </div>
    
                <?php }?>
          <div class="p-4">
            <label class="text-muted text-sm">在线充值</label>
                <form action="" method="post" onSubmit="return checkFm();" class="form-table form-group row">
                       <dl class="col-xs-12 col-sm-12 col-md-12">
                				<input type="text" id="ice_money" name="ice_money" required="required" class="form-control"  placeholder="请输入整数：￥1=<?php echo get_option('ice_proportion_alipay').' '.get_option('ice_name_alipay')?>"/><br />
                			</dl>


                                <?php if(get_option('ice_weixin_mchid')){?> 
                          <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
                                <input type="radio" id="paytype4" class="paytype" checked name="paytype" value="4" onclick="checkCard()" style="-webkit-appearance: none;"/>
                              <label for="paytype4"><img src="https://s2.ax1x.com/2019/08/17/mutmt0.png" class="mr-2"></label>
                              </span> 
                              </div>
                  
                                <?php }?>
                                <?php if(get_option('ice_ali_partner')){?> 
                                <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
                                <input type="radio" id="paytype1" class="paytype" checked name="paytype" value="1" onclick="checkCard()" style="-webkit-appearance: none;"/>
                              <label for="paytype1"><img src="https://s2.ax1x.com/2019/08/17/muulC9.png" class="mr-2"></label>
                              </span> 
                              </div>
                  
                                <?php }?>
                                <?php if(get_option('erphpdown_f2fpay_id')){?> 
                          <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
                              <input type="radio" id="paytype5" class="paytype" checked name="paytype" value="5" onclick="checkCard()" style="-webkit-appearance: none;"/>
							<label for="paytype5"><img src="https://s2.ax1x.com/2019/08/17/muulC9.png" class="mr-2"></label>
                              </span> 
                              </div>
                  
                                <?php }?>
                                <?php if(get_option('erphpdown_tenpay_uid')){?> 
                                <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
                                <input type="radio" id="paytype7" class="paytype" checked name="paytype" value="7" onclick="checkCard()" style="-webkit-appearance: none;"/>    
                              <label for="paytype7"><img src="https://s2.ax1x.com/2019/08/17/mutg4P.png" class="mr-2"></label>
                              </span> 
                              </div>
                  
                                <?php }?> 
                                <?php if(get_option('ice_china_bank_uid')){?> 
                                <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
                                <input type="radio" id="paytype3" class="paytype" checked name="paytype" value="3" onclick="checkCard()" style="-webkit-appearance: none;"/>
                              <label for="paytype3"><img src="https://s2.ax1x.com/2019/08/17/muulC9.png" class="mr-2"></label>
                              </span> 
                              </div>
                  
                                <?php }?>
                                <?php if(get_option('erphpdown_zfbjk_uid')){?> 
                                <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
                                <input type="radio" id="paytype8" class="paytype" checked name="paytype" value="8" onclick="checkCard()" style="-webkit-appearance: none;"/>    
                              <label for="paytype8"><img src="https://s2.ax1x.com/2019/08/17/muulC9.png" class="mr-2"></label>
                              </span> 
                              </div>
                  
                                <?php }?>
                                <?php if(get_option('erphpdown_xhpay_appid')){?> 
                                <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
				                <input type="radio" id="paytype9" class="paytype" name="paytype" value="9" checked onclick="checkCard()" style="-webkit-appearance: none;"/>
                              <label for="paytype9"><img src="https://s2.ax1x.com/2019/08/17/muulC9.png" class="mr-2"></label>
                              </span> 
                              </div>
                  
                            <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
				                <input type="radio" id="paytype10" class="paytype" name="paytype" value="10" checked onclick="checkCard()" style="-webkit-appearance: none;"/>
                                      <label for="paytype10"><img src="https://s2.ax1x.com/2019/08/17/mutmt0.png" class="mr-2"></label>
                              </span> 
                              </div>
                  
				                <?php }?> 
				                <?php if(get_option('erphpdown_xhpay_appid2')){?> 
                                <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
									<input type="radio" id="paytype12" class="paytype" name="paytype" value="12" checked onclick="checkCard()" style="-webkit-appearance: none;"/>
                              <label for="paytype12"><img src="https://s2.ax1x.com/2019/08/17/mutmt0.png" class="mr-2"></label>
                              </span> 
                              </div>
                  
                          <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
									<input type="radio" id="paytype11" class="paytype" name="paytype" value="11" checked onclick="checkCard()" style="-webkit-appearance: none;"/> 
                                      <label for="paytype11"><img src="https://s2.ax1x.com/2019/08/17/muulC9.png" class="mr-2"></label>
                              </span> 
                              </div>
                  
								<?php }?>
								<?php if(get_option('erphpdown_xhpay_appid31')){?> 
                         <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
									<input type="radio" id="paytype18" class="paytype" name="paytype" value="18" checked onclick="checkCard()" style="-webkit-appearance: none;"/>    
                              <label for="paytype18"><img src="https://s2.ax1x.com/2019/08/17/mutmt0.png" class="mr-2"></label>
                              </span> 
                              </div>
                  
								<?php }?>
								<?php if(get_option('erphpdown_xhpay_appid32')){?> 
                          <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
									<input type="radio" id="paytype17" class="paytype" name="paytype" value="17" checked onclick="checkCard()" style="-webkit-appearance: none;"/>   
                              <label for="paytype17"><img src="https://s2.ax1x.com/2019/08/17/muulC9.png" class="mr-2"></label>
                              </span> 
                              </div>
                  
								<?php }?>
				                <?php if(get_option('erphpdown_codepay_appid')){?> 
                        <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
				                <input type="radio" id="paytype13" class="paytype" name="paytype" value="13" checked onclick="checkCard()" style="-webkit-appearance: none;"/>
                              <label for="paytype13"><img src="https://s2.ax1x.com/2019/08/17/muulC9.png" class="mr-2"></label>
                              </span> 
                              </div>
                  
                        
                        <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
				                <input type="radio" id="paytype14" class="paytype" name="paytype" value="14" onclick="checkCard()" style="-webkit-appearance: none;"/>
                                  <label for="paytype14"><img src="https://s2.ax1x.com/2019/08/17/mutmt0.png" class="mr-2"></label>
                              </span> 
                              </div>
                         
                        <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
				                <input type="radio" id="paytype15" class="paytype" name="paytype" value="15" onclick="checkCard()" style="-webkit-appearance: none;"/>   
                            <label for="paytype15"><img src="https://s2.ax1x.com/2019/08/17/mut3nJ.png" class="mr-2"></label>
                              </span> 
                              </div>
                  
				                <?php }?>
				                <?php if(get_option('erphpdown_youzan_id')){?> 
                         <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
				                <input type="radio" id="paytype16" class="paytype" name="paytype" value="16" checked onclick="checkCard()" style="-webkit-appearance: none;"/>   
                              <label for="paytype16"><img src="https://s2.ax1x.com/2019/08/17/muulC9.png" class="mr-2"></label>
                              </span> 
                              </div>
                  
				                <?php }?> 
                                <?php if(get_option('ice_payapl_api_uid')){?> 
                          <div class="col-xs-6 col-sm-3 col-md-2">  
                            <span class="pay-span">
                                <input type="radio" id="paytype2" class="paytype" checked name="paytype" value="2" onclick="checkCard()" style="-webkit-appearance: none;"/>
                              <label for="paytype2"><img src="https://s2.ax1x.com/2019/08/17/muNeDH.png" class="mr-2"></label>
                              </span> 
                              </div>
                                 (<?php echo get_option('ice_payapl_api_rmb')?>)
                                 <?php }?> 
                                    
                        <dl class="col-xs-12 col-sm-12 col-md-12 submit" style="margin-top:10px;">
                            <input type="submit" name="Submit" value="充值" class="btn btn-primary btn-primary-1" onClick="return confirm('确认充值?');" style="-webkit-appearance: none;"/>
                        </dl>
                    
                </form>
                </div>

                </div>
			<?php } ?>
		</div>
    </div>
 
  </main>

<script type="text/javascript">
	function strlen(str){
		var len = 0;
		for (var i=0; i<str.length; i++){
			var c = str.charCodeAt(i);
			if ((c >= 0x0001 && c <= 0x007e) || (0xff60<=c && c<=0xff9f)) {
				len++;
			}else {
				len+=2;
			}
		} 
		return len;
	}
</script>
<?php get_footer(); ?>